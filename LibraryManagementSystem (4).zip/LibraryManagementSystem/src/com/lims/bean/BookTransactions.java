package com.lims.bean;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class BookTransactions {
	
	@Id
	@GeneratedValue
	@Column(name="TRANSACTION_ID")
	private int transactionId;
	@Column(name="BOOK_NAME")
	private String bookName;
	@Column(name="USER_ID")
	private int userId;
	@Column(name="ISSUE_DATE")
	//@DateTimeFormat
	private LocalDate issueDate;
	@Column(name="RETURN_DATE")
	//@DateTimeFormat
	private LocalDate returnDate;
	@Column(name="AUTHOR1")
	private String author1;
	@Column(name="AUTHOR2")
	private String author2;
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor1() {
		return author1;
	}
	public void setAuthor1(String author1) {
		this.author1 = author1;
	}
	public String getAuthor2() {
		return author2;
	}
	public void setAuthor2(String author2) {
		this.author2 = author2;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDate getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(LocalDate localDate) {
		this.issueDate = localDate;
	}
	public LocalDate getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(LocalDate localDate) {
		this.returnDate = localDate;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
}
