package com.lims.bean;

import javax.persistence.*;

@Entity
public class BookTransactions {
	
	@Id
	@GeneratedValue
	@Column(name="TRANSACTION_ID")
	private int transactionId;
	@Column(name="BOOK_NAME")
	private String bookName;
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	@Column(name="ISSUE_DATE")
	private int issueDate;
	@Column(name="RETURN_DATE")
	private int returnDate;
	@Column(name="AUTHOR1")
	private String author1;
	@Column(name="AUTHOR2")
	private String author2;
	public String getAuthor1() {
		return author1;
	}
	public void setAuthor1(String author1) {
		this.author1 = author1;
	}
	public String getAuthor2() {
		return author2;
	}
	public void setAuthor2(String author2) {
		this.author2 = author2;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(int issueDate) {
		this.issueDate = issueDate;
	}
	public int getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(int returnDate) {
		this.returnDate = returnDate;
	}
	
	
	
}
