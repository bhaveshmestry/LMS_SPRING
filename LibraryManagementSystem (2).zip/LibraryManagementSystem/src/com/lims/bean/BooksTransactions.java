package com.lims.bean;

import javax.persistence.*;

@Entity
@Table(name="BooksTransaction")
public class BooksTransactions {
	
	@Id
	@GeneratedValue
	@Column(name="transaction_id")
	private int transactionId;
	@Column(name="issue_date")
	private int issueDate;
	@Column(name="return_date")
	private int returnDate;
	@Column(name="fine")
	private int fine;
	@OneToOne
	@JoinColumn(name="registration_id")
	private BooksRegistration registrationId;
	
	public BooksTransactions() {
		
	}
	public int getFine() {
		return fine;
	}
	public void setFine(int fine) {
		this.fine = fine;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(int issueDate) {
		this.issueDate = issueDate;
	}
	public int getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(int returnDate) {
		this.returnDate = returnDate;
	}
}
