package com.lims.bean;

import javax.persistence.*;

@Entity
@Table(name="Users")
@NamedQuery(name = "loginqryadmin", query = "select u from Users u where u.userName =:user and u.password =:pass")
public class Users {

	@Id
	@GeneratedValue
	@Column(name="user_id")
	private int userID;
	@Column(name="user_name")
	private String userName;
	@Column(name="password")
	private String password;
	@Column(name="email_id")
	private String emailId;
	@Column(name="librarian")
	private boolean librarian;
	public Users() {
	}
	
	public boolean isLibrarian() {
		return librarian;
	}

	public void setLibrarian(boolean librarian) {
		this.librarian = librarian;
	}

	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
}
