package com.lims.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BooksRegistration")

public class BooksRegistration {
	@Id
	@GeneratedValue
	@Column(name="registration_id")
	private int registrationId;
	@Column(name="registrationdate")
	private Date registrationDate;
	@OneToOne
	@JoinColumn(name="book_id")
	private BooksInventory bookId;
	@OneToOne
	@JoinColumn(name="user_id")
	private Users userID;
	public BooksRegistration() {
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

}
