package com.lims.dao;

import java.util.ArrayList;

import com.lims.bean.BooksInventory;
import com.lims.bean.Users;

public interface ILIMSDao {

	boolean login(String userName, String password, Users user1);
	
	ArrayList<BooksInventory> view(BooksInventory inventory);

}
