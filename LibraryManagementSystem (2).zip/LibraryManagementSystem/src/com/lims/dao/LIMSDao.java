package com.lims.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lims.bean.BooksInventory;
import com.lims.bean.Users;

@Repository
@Transactional
public class LIMSDao implements ILIMSDao{

	@PersistenceContext 
	EntityManager entitymanager;

	@Override
	public boolean login(String userName, String password, Users user1) {
		boolean status = true;
		Query qry = entitymanager.createNamedQuery("loginqryadmin");
		qry.setParameter("user",user1.getUserName());
		qry.setParameter("pass",user1.getPassword());
		List result =qry.getResultList();
		System.out.println(result);
		if(result.isEmpty())
		{
			status = false;
		}
		return status;
	}

	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		Query qry = entitymanager.createNamedQuery("viewalladmin");
		ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		return list;
	}

	@Override
	public int addBook(BooksInventory inventory) {
		entitymanager.persist(inventory);
		return inventory. getBookId();
	}

	@Override
	public int deleteBook(int deleteBookId) {
		Query deleteQuery=entitymanager.createQuery("delete BooksInventory where bookId =:delbookid");
		deleteQuery.setParameter("delbookid",deleteBookId);
		int result = deleteQuery.executeUpdate();
		return result;
	}

	@Override
	public BooksInventory updateSearchBook(int booksearchId) {
		try{
		Query updateQuery=entitymanager.createQuery("select book from BooksInventory book where bookId =:upbookid");
		updateQuery.setParameter("upbookid", booksearchId);
		BooksInventory result = (BooksInventory) updateQuery.getSingleResult();
		return result;
		}
		catch(Exception e)
		{
			return null;
		}
		
	}
	@Override
	public int updateBook(BooksInventory inventory) {
		entitymanager.merge(inventory);
		return inventory. getBookId();
	}


}
