package com.lims.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lims.bean.BooksInventory;
import com.lims.bean.Users;

@Repository
@Transactional
public class LIMSDao implements ILIMSDao{

	@PersistenceContext
	EntityManager entitymanager = null;
	
	@Override
	public boolean login(String userName, String password, Users user1) {
		boolean status = true;
		Query qry = entitymanager.createNamedQuery("loginqry");
		qry.setParameter("user",user1.getUserName());
		qry.setParameter("pass",user1.getPassword());
		List result =qry.getResultList();
		System.out.println(result);
		if(result.isEmpty())
		{
			status = false;
		}
		return status;
	}

	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		// TODO Auto-generated method stub
		Query qry = entitymanager.createNamedQuery("view");
		ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		return list;
	}

}
