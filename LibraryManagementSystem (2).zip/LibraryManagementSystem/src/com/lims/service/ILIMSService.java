package com.lims.service;

import java.util.ArrayList;

import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;



public interface ILIMSService {

	boolean login(String userName, String password, Users user1); 

	ArrayList<BooksInventory> view(BooksInventory inventory);

	boolean placeRequest(String bookName,BookTransactions bookTrans);
	

	
}
