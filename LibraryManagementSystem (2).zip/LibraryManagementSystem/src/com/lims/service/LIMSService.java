package com.lims.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;
import com.lims.dao.ILIMSDao;

@Service
public class LIMSService implements ILIMSService{

	@Autowired
	ILIMSDao dao = null;
	
	@Override
	public boolean login(String userName, String password, Users user1) {
		
		return dao.login(userName,password,user1);
	}

	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		
		return dao.view(inventory);
	}

	@Override
	public boolean placeRequest(String bookName, BookTransactions bookTrans) {
		return false;
	}

}
