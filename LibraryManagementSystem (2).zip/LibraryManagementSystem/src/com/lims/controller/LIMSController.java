package com.lims.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lims.bean.BooksInventory;
import com.lims.bean.Users;
import com.lims.service.ILIMSService;

@Controller
public class LIMSController {

	@Autowired
	ILIMSService service;
	@RequestMapping("home")
	public String home(){
		
		return "home";
	}
	@RequestMapping("aboutus")
	public String aboutus(){
		
		return "aboutus";
	}
	@RequestMapping("loginadmin")
	public String login(Model m,@ModelAttribute("contentObj") Users user){
		
		m.addAttribute("contentObj",user);
		return "loginadmin";
	}
	@RequestMapping("contentadmin")
	public String backToContent(Model m,@ModelAttribute("contentObj") Users user){
		
		m.addAttribute("contentObj",user);
		return "contentadmin";
	}

	@RequestMapping("content")
	public String gotoservice(Model m, @ModelAttribute("contentObj") Users user1){
		String target = null;
		m.addAttribute(user1);
		m.addAttribute("user",user1.getUserName());
		m.addAttribute("pass",user1.getPassword());
		boolean val = service.login(user1.getUserName(), user1.getPassword() , user1);
		if(val)
		{
			target = "contentadmin";
			
		}
		else
		{
			target = "loginadmin";
			m.addAttribute("status","Login Unsuccessful");
			
		}
		return target;
	}
	
	
	@RequestMapping("viewallbooksadmin")
	public String getAllBooksAdmin(Model m,BooksInventory inventory)
	{
		ArrayList<BooksInventory> list = service.view(inventory);
		m.addAttribute("list",list);
		return "viewallbooksadmin";
	}
	@RequestMapping("addbook")
	public String getAdd(Model m)
	{
		m.addAttribute("bookinventoryObj",new BooksInventory());
		return "addbook";
	}
	@RequestMapping(value="successadd",method=RequestMethod.POST)
	public String addBook(Model m,@ModelAttribute("bookinventoryObj") BooksInventory inventory)
	{
		String target=null;
		int id=service.addBook(inventory);
		if(id>0)
		{
			System.out.println("in if");
			m.addAttribute("msg","Book stored to Booklist with id:");
			m.addAttribute("id",id);
			target="successadd";
		}
		else
		{
			target="contentadmin";
		}
		return target;
		
	}
	
	@RequestMapping("updatesearch")
	public String getUpdate(Model m)
	{
		m.addAttribute("bookinventoryObj",new BooksInventory());
		return "updatesearch";
	}
	@RequestMapping(value="update",method=RequestMethod.POST)
	public String updateScheduleDetailsPage(Model m,@ModelAttribute("bookinventoryObj") BooksInventory inventory)
	{
		String target=null;
		int booksearchId=inventory.getBookId();
		BooksInventory result=service.updateSearchBook(booksearchId);
		if(result==null)
		{
			target="updatesearch";
			m.addAttribute("msg","No such book Available");
		}
		else
		{
			m.addAttribute("updatelist",result);
			System.out.println("In controller");
			target="updatebook";	
		}
		return target;
	} 
	@RequestMapping(value="successupdate",method=RequestMethod.POST)
	public String updateBook(Model m,@ModelAttribute("bookinventoryObj") BooksInventory inventory)
	{
		String target=null;
		int id=service.updateBook(inventory);
		if(id>0)
		{
			System.out.println("in if");
			m.addAttribute("msg","Book details updated Successfully");
			target="successupdate";
		}
		else
		{
			target="contentadmin";
		}
		return target;
	}
	@RequestMapping("delete")
	public String getDelete(Model m)
	{
		m.addAttribute("bookinventoryObj",new BooksInventory());
		return "deletebook";
	}
	@RequestMapping(value="successdelete",method=RequestMethod.POST)
	public String deleteBook(Model m,@ModelAttribute("bookinventoryObj") BooksInventory inventory)
	{
		String target=null;
		int deleteBookId=inventory.getBookId();
		int result;
		result=service.deleteBook(deleteBookId);
		if(result>0)
		{
			System.out.println("in if");
			m.addAttribute("msg","Book details updated Successfully");
			target="contentadmin";
		}
		else
		{
			target="deletebook";
			m.addAttribute("msg","Cannot find such book to delete");
		}
		return target;
	}
	
}
