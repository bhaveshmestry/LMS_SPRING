package com.lims.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;
import com.lims.service.ILIMSService;
import com.lims.service.LIMSService;

@Controller
public class LIMSController {

	@Autowired
	ILIMSService service;
	
	@RequestMapping("index")
	public String index(Model m,@ModelAttribute("loginObj") Users usr1,@ModelAttribute("regObj") Users usr2){
		m.addAttribute(usr1);
		m.addAttribute(usr2);
		return "index";
	}
	
	@RequestMapping("login") 
	public String login(Model m,@ModelAttribute("contentObj") Users usr){
		m.addAttribute(usr);
		return "login";
	}
	@RequestMapping("register")
	public String register(Model m,@ModelAttribute("registerObj") Users usr3){
		m.addAttribute(usr3);
		return "register";
	}
	@RequestMapping("content")
	public String gotoservice(Model m, @ModelAttribute("contentObj") Users user1){
		String target = null;
		m.addAttribute(user1);
		m.addAttribute("usr",user1.getUserName());
		m.addAttribute("pass",user1.getPassword());
		boolean val = service.login(user1.getUserName(), user1.getPassword() , user1);
		if(val)
		{
			target = "content";
			
		}
		else
		{
			target = "login";
			m.addAttribute("status","Login Unsuccessful");
			
		}
		return target;
	}
	
	@RequestMapping("viewbooks")
	public String viewbooks(Model m,BooksInventory inventory)
	{	
		ArrayList<BooksInventory> list = service.view(inventory);
		m.addAttribute("list",list);
		return "viewall";
	}
	
	@RequestMapping("request" )
	public String placereq(Model m, @ModelAttribute("requestObj") BookTransactions transaction)
	{	
		
		return "request";
	}

	@RequestMapping("return" )
	public String returnBook(Model m, @ModelAttribute("returnObj") BookTransactions transaction)
	{	
		
		return "return";
	}

}
