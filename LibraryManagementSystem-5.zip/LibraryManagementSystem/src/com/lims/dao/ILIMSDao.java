package com.lims.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;

public interface ILIMSDao {

	boolean login(String userName, String password, Users user1);
	
	ArrayList<BooksInventory> view(BooksInventory inventory);

	String register( Users usr);

	String placerequest(BookTransactions transactions, BooksInventory inventory);

	ArrayList<BooksInventory> view(BooksInventory inventory, String bookName);

}
