package com.lims.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;

@Repository
@Transactional
public class LIMSDao implements ILIMSDao{

	@PersistenceContext
	EntityManager entitymanager ;
	
	@Override
	public boolean login(String userName, String password, Users user1) {
		boolean status = true;
		Query qry = entitymanager.createNamedQuery("loginqry");
		qry.setParameter("user",user1.getUserName());
		qry.setParameter("pass",user1.getPassword());
		List result =qry.getResultList();
		System.out.println(result);
		if(result.isEmpty())
		{
			status = false;
		}
		return status;
	}

	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		// TODO Auto-generated method stub
		Query qry = entitymanager.createNamedQuery("view");
		ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		return list;
	}

	@Override
	public String register(Users usr) {
		
		System.out.println(entitymanager);
		entitymanager.persist(usr);
		
		System.out.println(usr.getUserName());
		
		
		return "Registered Successfully";
	}

	@Override
	public String placerequest(BookTransactions transactions,BooksInventory inventory) 
	{
		transactions.setIssueDate(new Date());
		Calendar c = Calendar.getInstance();
		 c.setTime(transactions.getIssueDate());
		 c.add(Calendar.DAY_OF_MONTH, 7);
		 Date date = c.getTime();
		 transactions.setReturnDate(date);
		 transactions.setFine(0);
		 
		entitymanager.persist(transactions);
		
		return "Request for the book is placed";
	}

	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory,
			String bookName) {
			
			Query qry = entitymanager.createQuery("Select s from BooksInventory s where s.bookName=:name");
			qry.setParameter("name",inventory.getBookName());
			ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		return list;
	}

}
