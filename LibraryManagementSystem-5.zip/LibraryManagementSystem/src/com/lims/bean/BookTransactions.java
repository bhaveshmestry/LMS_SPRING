package com.lims.bean;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class BookTransactions {
	
	@Id
	@GeneratedValue
	@Column(name="TRANSACTION_ID")
	private int transactionId;
	@Column(name="ISSUE_DATE")
	private Date issueDate;
	@Column(name="RETURN_DATE")
	private Date returnDate;
	@Column(name="FINE")
	private int fine;
	

	@OneToOne
	@JoinColumn(name ="REGISTRATION_ID")
	private BookRegistration registrationId;
	

	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date localDate) {
		this.issueDate = localDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date localDate) {
		this.returnDate = localDate;
	}
	
	public BookRegistration getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(BookRegistration registrationId) {
		this.registrationId = registrationId;
	}
	public int getFine() {
		return fine;
	}
	public void setFine(int fine) {
		this.fine = fine;
	}
	

	
}
