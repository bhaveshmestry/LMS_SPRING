package com.lims.bean;

import javax.persistence.*;

@Entity
@NamedQueries({
@NamedQuery(query="select u from Users u where u.userName =:user and u.password =:pass and u.librarian='0'",name="userLoginQry"),
@NamedQuery(query="select u from Users u where u.userName =:user and u.password =:pass and u.librarian='1'",name="adminLoginQry")
})
public class Users {

	@Id
	@GeneratedValue
	@Column(name="USER_ID")
	private int userID;
	@Column(name="USER_NAME")
	private String userName;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="EMAIL_ID")
	private String emailId;
	@Column(name="librarian")
	private boolean librarian;
	
	public boolean isLibrarian() {
		return false;
	}
	public void setLibrarian(boolean librarian) {
		this.librarian = librarian;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
	
}
