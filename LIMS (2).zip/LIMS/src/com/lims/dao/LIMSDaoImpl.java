package com.lims.dao;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lims.bean.BookRegistration;
import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;


@Repository
@Transactional
public class LIMSDaoImpl implements ILIMSDao{

	@PersistenceContext
	EntityManager entitymanager;
	
	
	@Override
	public boolean userLogin(String userName, String password, Users usr) {
		
		boolean status = true;
		Query qry = entitymanager.createNamedQuery("userLoginQry");
		qry.setParameter("user",usr.getUserName());
		qry.setParameter("pass",usr.getPassword());
		List result = qry.getResultList();
		System.out.println(result);
		if(result.isEmpty())
		{
			status = false;
		}
		
		return status;
	}


	@Override
	public String register(Users usr) {

		System.out.println(entitymanager);
		entitymanager.persist(usr);
		
		return "Registered Successfully";
	}


	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		
		Query qry = entitymanager.createNamedQuery("view");
		ArrayList<BooksInventory> list = (ArrayList<BooksInventory>) qry.getResultList();
		
		return list;
	}


	@Override
	public boolean adminLogin(String userName, String password, Users usr) {
		
		boolean status = true;
		Query qry = entitymanager.createNamedQuery("adminLoginQry");
		qry.setParameter("user",usr.getUserName());
		qry.setParameter("pass",usr.getPassword());
		List result = qry.getResultList();
		System.out.println(result);
		if(result.isEmpty())
		{
			status = false;
		}
		
		return status;
	}


	@Override
	public int addBook(BooksInventory inventory) {
		
		entitymanager.persist(inventory);
		
		int id = inventory.getBookId();
		return id;
		
	}


	@Override
	public int updateBook(BooksInventory inventory) {

		entitymanager.merge(inventory);
		
		return inventory. getBookId();
		
	}


	@Override
	public BooksInventory updateSearchBook(int booksearchId) {

		try{
			Query updateQuery=entitymanager.createQuery("select book from BooksInventory book where bookId =:upbookid");
			updateQuery.setParameter("upbookid", booksearchId);
			BooksInventory result = (BooksInventory) updateQuery.getSingleResult();
			return result;
			}
			catch(Exception e)
			{
				return null;
			}
	}


	@Override
	public int deleteBook(int deleteBookId) {

		Query deleteQuery=entitymanager.createQuery("delete BooksInventory where bookId =:delbookid");
		deleteQuery.setParameter("delbookid",deleteBookId);
		int result = deleteQuery.executeUpdate();
		return result;
		
	}


	@Override
	public String placerequest(BookRegistration registration) {
		registration.setRegistrationDate(new Date());
		entitymanager.persist(registration);
		
		return "Request for the book is placed";
	}


	@Override
	public ArrayList<BookRegistration> viewRequest(BookRegistration bookRegistration) {

		Query qry = entitymanager.createQuery("select r from BookRegistration r");
		ArrayList<BookRegistration> list = (ArrayList<BookRegistration>) qry.getResultList();
		System.out.println("List working "+list);
		return list;
	}

}
