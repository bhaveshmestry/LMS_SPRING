package com.lims.dao;

import java.util.ArrayList;

import com.lims.bean.BookRegistration;
import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;

public interface ILIMSDao {

	boolean userLogin(String userName, String password, Users usr);

	String register(Users usr);

	ArrayList<BooksInventory> view(BooksInventory inventory);

	boolean adminLogin(String userName, String password, Users usr);

	int addBook(BooksInventory inventory);

	int updateBook(BooksInventory inventory);

	BooksInventory updateSearchBook(int booksearchId);

	int deleteBook(int deleteBookId);

	String placerequest(BookRegistration registration);

	ArrayList<BookRegistration> viewRequest(BookRegistration bookRegistration);
}
