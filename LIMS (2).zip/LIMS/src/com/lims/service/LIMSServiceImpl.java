package com.lims.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lims.bean.BookRegistration;
import com.lims.bean.BookTransactions;
import com.lims.bean.BooksInventory;
import com.lims.bean.Users;
import com.lims.dao.ILIMSDao;


@Service
public class LIMSServiceImpl implements ILIMSService{

	@Autowired
	ILIMSDao dao;
	
	
	@Override
	public boolean userLogin(String userName, String password, Users usr) {
	
		return dao.userLogin(userName,password,usr);
	}


	@Override
	public String register(Users usr) {
		
		return dao.register(usr);
	}


	@Override
	public ArrayList<BooksInventory> view(BooksInventory inventory) {
		
		return dao.view(inventory);
	}


	@Override
	public boolean adminLogin(String userName, String password, Users usr) {
		
		return dao.adminLogin(userName,password,usr);
	}


	@Override
	public int addBook(BooksInventory inventory) {

		return dao.addBook(inventory);
		 
	}


	@Override
	public int updateBook(BooksInventory inventory) {

			return dao.updateBook(inventory);
	}


	@Override
	public BooksInventory updateSearchBook(int booksearchId) {

		return dao.updateSearchBook(booksearchId);
	}


	@Override
	public int deleteBook(int deleteBookId) {
		
		return dao.deleteBook(deleteBookId);
	}


	@Override
	public String placerequest(BookRegistration registration) {

		return dao.placerequest(registration);
	}


	@Override
	public ArrayList<BookRegistration> viewRequest(BookRegistration bookRegistration) {
		
		return dao.viewRequest(bookRegistration);
	}

}
